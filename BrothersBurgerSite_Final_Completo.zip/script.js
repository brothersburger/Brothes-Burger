
// Animações ou interações básicas podem ir aqui
console.log("Brother's Burger site carregado!");
